<?php
/**
 * The template for displaying the footer
 */
 global $theme_option; 
?>
		<!--Footer-->
		<footer class="footer  offset">
			<!--Container-->
			<div class="container clearfix">
				<div class="eight columns">
					<?php if($theme_option['footer_text']!=''){ ?>
						<?php echo esc_attr($theme_option['footer_text']); ?>
					<?php } ?>
				</div>
				<div class="eight columns ">
					<ul class="right">
						<?php if($theme_option['facebook']!=''){ ?>
						<li><a href="<?php echo esc_url($theme_option['facebook']); ?>">FaceBook</a></li>
						<?php } ?>
						<?php if($theme_option['google']!=''){ ?>
						<li><a href="<?php echo esc_url($theme_option['google']); ?>">Google</i></a></li>
						<?php } ?>
						<?php if($theme_option['twitter']!=''){ ?>
						<li><a href="<?php echo esc_url($theme_option['twitter']); ?>">Twitter</a></li>
						<?php } ?>
						<?php if($theme_option['youtube']!=''){ ?>
						<li><a href="<?php echo esc_url($theme_option['youtube']); ?>">Youtube</a></li>
						<?php } ?>
						<?php if($theme_option['linkedin']!=''){ ?>
						<li><a href="<?php echo esc_url($theme_option['linkedin']); ?>">LinkedIn</a></li>
						<?php } ?>
						<?php if($theme_option['dribbble']!=''){ ?>
						<li><a href="<?php echo esc_url($theme_option['dribbble']); ?>">Dribbble</a></li>
						<?php } ?>
						<?php if($theme_option['pinterest']!=''){ ?>
						<li><a href="<?php echo esc_url($theme_option['pinterest']); ?>">Pinterest</a></li>
						<?php } ?>
						<?php if($theme_option['instagram']!=''){ ?>
						<li><a href="<?php echo esc_url($theme_option['instagram']); ?>">Instagram</a></li>
						<?php } ?>
						<?php if($theme_option['skype']!=''){ ?>
						<li><a href="<?php echo esc_url($theme_option['skype']); ?>">Skype</a></li>
						<?php } ?>	
					</ul>
				</div>
			</div>
			<!--End container-->
		</footer>
		<!--End footer-->	
</div>
<!--ENd wrapper-->

<?php wp_footer(); ?>
</body>
</html>