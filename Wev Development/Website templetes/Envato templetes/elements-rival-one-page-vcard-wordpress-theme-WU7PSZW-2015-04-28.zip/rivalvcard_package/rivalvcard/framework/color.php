<?php
$root =dirname(dirname(dirname(dirname(dirname(__FILE__)))));
//echo $root; 
if ( file_exists( $root.'/wp-load.php' ) ) {
    require_once( $root.'/wp-load.php' );
} elseif ( file_exists( $root.'/wp-config.php' ) ) {
    require_once( $root.'/wp-config.php' );
}
header("Content-type: text/css; charset=utf-8");
global $theme_option; 
?>
/* Color Theme - Amethyst /Violet/

color - <?php echo $theme_option['main-color']; ?>

/* 01 MAIN STYLES
****************************************************************************************************/
a {
  color: <?php echo $theme_option['main-color']; ?>;
}
::selection {
  color: #fff;
  background: <?php echo $theme_option['main-color']; ?>;
}
::-moz-selection {
  color: #fff;
  background: <?php echo $theme_option['main-color']; ?>;
}
.prTitle, .service h2, .otherList ul i, .planHeader.featured .planPrice h1, .planHeader.featured .planName h3,
.doubleBtn.planBtn.featured a, ul#category li a:hover, #category .current a, h1.projTitle span, .iList li i, .postMeta a,
.pagination ul li a:hover, .pagination ul li a.current, .pagination ul li span.current, .postSingle blockquote, .tagsListSingle li a:hover,
.commentContent .date a , .searchForm  .submitSearch, .widget_archive li a, .widget_meta ul abbr, .widget_categories ul li , 
.widget_categories li span.countCat, .wp-tag-cloud li a:hover, #error h2, .btn a:hover, .tagsListSingle li a:hover, .tagsList li a:hover, 
.contactForm #submit:hover , .replyForm #submit:hover, .projSocials li a:hover, .projNav li a:hover, .comments .reply-btn a:hover,
.doubleBtn .choose, .postSingle blockquote p, .mainNav .dropdown-menu li  a:hover,
.infoSocial li a,.detRight.current,.detRight.current:before,.percentage,ul#category li a:hover,#category .current a,h1.projTitle span,
.iList li i,.postMeta a,.pagination ul li a:hover, .pagination ul li span:hover,.pagination ul li a.selected,.postSingle blockquote,
.tagsListSingle li a:hover,.commentContent .date a ,.searchForm  .submitSearch,.catArchives li a, .meta abbr,
.catList li span.countCat,.widget_archive li a, .widget_meta ul abbr, .widget_categories ul li,.widget_categories li span.countCat,
.wp-tag-cloud li a:hover,#error h2,.errorForm,.infoSocial li a
{color: <?php echo $theme_option['main-color']; ?>;}

.tagsListSingle li a, #wp-calendar tbody td#today,.percentage,.timeLineIco span.ico
{background: <?php echo $theme_option['main-color']; ?>;}

.detRight.current{
	border: 3px solid <?php echo $theme_option['main-color']; ?>;
}
.detRight.current:before {
border-bottom: 15px solid <?php echo $theme_option['main-color']; ?>;
}
/************** FOOTER *******************/
.footer {
  background: none repeat scroll 0 0 <?php echo $theme_option['background-footer']; ?>;
  color: <?php echo $theme_option['color-footer']; ?>;
}
.right li a {color: <?php echo $theme_option['color-footer']; ?>;}