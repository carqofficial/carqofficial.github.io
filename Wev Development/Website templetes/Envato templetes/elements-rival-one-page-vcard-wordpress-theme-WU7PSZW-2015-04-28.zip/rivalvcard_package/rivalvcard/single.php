<?php
/**
 * The Template for displaying all single posts
 */
$textdoimain = 'rivalvcard';
get_header(); ?>
<!--BLog single section-->
<section id="blogSingle" class="blogSingle singleOffset ofsBottom">
	<!--Container-->
	<div class="container clearfix">
		<div class="eleven columns">
									
			<!--Post Single-->
			<div class="postSingle">
				<!--Post content-->
				<div class="postContent">
				<?php
					// Start the Loop.
					while ( have_posts() ) : the_post();?>
						
					<div class="postTitle">
						<h5><?php the_title(); ?> <span class="postDate">/ <?php the_time('j F'); ?></span></h5>
						
						<!--Post meta-->
						<div class="postMeta">
							<span class="metaAuthor"><?php echo esc_attr($theme_option['postby']); ?> <?php the_author_posts_link(); ?></span>
							<span class="metaCategory">/ <?php the_category(', '); ?></span>
							<span class="metaComment">/ <?php comments_popup_link(__(' 0 comment', $textdoimain), __(' 1 comment', $textdoimain), ' % comments'.__('', $textdoimain)); ?></span>
						</div>
						<!--End post meta-->					
					</div>
					
					<?php $format = get_post_format();?>
						<?php if($format == 'gallery'){?>
							<!--Post media-->
							<?php $gallery = get_post_gallery( get_the_ID(), false );
								if(isset($gallery['ids'])){ ?>
							<div class="postMedia postSliderLarge flexslider large">
								<ul class="slides">
									<?php
											$gallery_ids = $gallery['ids'];
											$img_ids = explode(",",$gallery_ids);
											foreach( $img_ids AS $img_id ){
											$image_src = wp_get_attachment_image_src($img_id,'');
										?>
										
										<li>
											<?php $params = array( 'width' => 640, 'height' => 385 );
											  $image = bfi_thumb( $image_src[0], $params ); ?>
											<img width="640" height="385" src="<?php echo esc_url($image); ?>" alt="<?php the_title(); ?>" >											
										</li>
									
									<?php }?>
								</ul>
							</div>
						<?php }?>
							<!--End post media-->
						<?php }elseif($format == 'video'){?>
							<!--Post media-->
						<!--Post media-->
						<?php $link_video = get_post_meta(get_the_ID(),'_cmb_link_video', true);?>
						<?php if($link_video !=''){?>
							<div class="postMedia large">
								<iframe height="360" src="<?php echo get_post_meta(get_the_ID(),'_cmb_link_video', true);?>" allowfullscreen></iframe>								
							</div>
							<?php }?>
							<!--End post media-->
							<?php }elseif($format == 'audio'){?>
							<!--Post media-->
							<div class="postMedia large">
								<iframe width="100%" height="166" scrolling="no" frameborder="no" src="<?php echo get_post_meta(get_the_ID(), "_cmb_link_audio", true);?>&amp;color=ff5500&amp;auto_play=false&amp;hide_related=false&amp;show_artwork=true"></iframe>
							</div>
							<!--End post media-->	
						<?php }else{ ?>
							<!--Post media-->
							<div class="postMedia large">
								<?php $params = array( 'width' => 640, 'height' => 385 );
								  $image = bfi_thumb( wp_get_attachment_url(get_post_thumbnail_id()), $params ); ?>
								<img width="640" height="385" src="<?php echo esc_url($image); ?>" alt="<?php the_title(); ?>" >																				
							</div>	
							<!--End post media-->
						<?php }?>
					
					<?php the_content(); ?>	
					
					<?php wp_link_pages(); ?>
					
					<div class="tagsSingle clearfix">
						<h4><i class="icon-tag-1"></i>Tags :</h4>
							<?php
								if(get_the_tag_list()) {
									echo get_the_tag_list('<ul class="tagsListSingle"><li>','</li><li>','</li></ul>');
								}
							?>
					</div>
				<?php endwhile; ?>	 
				</div>
				<!--End post content-->	
			</div>
			<!--End post single-->	
			
			<?php comments_template();?>
			
		</div>					
		<div class="five columns sidebar">
			<?php get_sidebar(); ?>
		</div>		
	</div>
	<!--End container-->
</section>
<!--End blog single section-->

<?php
get_footer();
