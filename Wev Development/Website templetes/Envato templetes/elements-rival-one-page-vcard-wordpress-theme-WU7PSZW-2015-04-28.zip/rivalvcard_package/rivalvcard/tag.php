<?php
/**
 * Main Template
 */
 global $theme_option;
 $textdoimain = 'rivalvcard';
get_header(); ?>

						<!--BLog full section-->
						<section id="blogFull" class="blogFull singleOffset ofsBottom">

								<!--Container-->
								<div class="container clearfix">
									
							<div class="sixteen columns">
									<h1 class="title tCenter"><?php printf( __( 'Tag Archives: %s', $textdoimain ), single_tag_title( '', false ) ); ?></h1> 
                                </div>
									
								<div class="eleven columns">
									
									<!--Post large-->
                                  <?php 
				
									$j=0;
									while (have_posts()) : the_post(); 
									$j++; ?>  
                                    
									<div class="postLarge">

							<!--Post content-->
							<div class="postContent">

								<div class="postTitle">
								<h1><a href="<?php the_permalink();?>"><?php the_title();?> <span class="postDate">/ <?php the_time('j F');?></span></a></h1>
								
								<!--Post meta-->
								<div class="postMeta">
								<span class="metaAuthor"><?php echo esc_attr($theme_option['postby']); ?> <?php the_author_posts_link(); ?></span>
								<span class="metaCategory">/ <?php
									$category = get_the_category();
									if ($category) {
									  echo '<a href="' . get_category_link( $category[0]->term_id ) . '" title="' . sprintf( __( "View all posts in %s", $textdoimain ), $category[0]->name ) . '" ' . '>' . $category[0]->name.'</a> ';
									}
								?></span>
								<span class="metaComment">/ <?php comments_popup_link(__(' 0 comment', $textdoimain), __(' 1 comment', $textdoimain), ' % comments'.__('', $textdoimain)); ?></span>
								</div>
								<!--End post meta-->
								
								</div>
								
									<!--Post image-->
                                    <?php $format = get_post_format($post->ID); ?>
                                <?php if($format=='image'){?>
									<?php if ( has_post_thumbnail() ) { ?>
                                    <div class="postMedia large">
										<a href="<?php the_permalink();?>">
                                        <?php $params = array( 'width' => 640, 'height' => 385 );
										$image = bfi_thumb( wp_get_attachment_url(get_post_thumbnail_id()), $params ); ?>
											<img alt="<?php the_title(); ?>" src="<?php echo esc_url($image);?>" height="385" width="640" />
										</a>
									</div>
                                    <?php }?>
                                <?php }elseif($format=='gallery'){?>
                                <div class="postMedia postSliderLarge flexslider large">
									<ul class="slides">
									<?php $gallery = get_post_gallery( get_the_ID(), false );
									if(isset($gallery['ids'])){ 
									      $gallery_ids = $gallery['ids'];
									      $img_ids = explode(",",$gallery_ids);
										  $i=0;
										 	
									        foreach( $img_ids AS $img_id ){
									        $image_src = wp_get_attachment_image_src($img_id,''); 
											$i++;		
									        ?>
												
												<?php $params = array( 'width' => 640, 'height' => 385 );
													$image = bfi_thumb( $image_src[0], $params ); ?>
												<li><a href="blog_single.html"><img alt="<?php the_title(); ?>" src="<?php echo esc_url($image); ?>" height="385" width="640"/></a></li>													
												  
											<?php 
								            }
										}
									      ?>
									</ul>
								</div>
                                <?php }elseif($format=='video'){?>
                                <?php $link_video = get_post_meta(get_the_ID(),'_cmb_link_video', true);?>
                                <?php if($link_video !=''){?>
                                <div class="postMedia large">
									<iframe height="360" src="<?php echo get_post_meta(get_the_ID(),'_cmb_link_video', true);?>" allowfullscreen></iframe>
								</div>
                                <?php }?>
                                <?php }elseif($format == 'audio'){?>
                                <div class="postMedia large">
                                    <div class="video-wrapper">
    								<iframe width="100%" height="166" scrolling="no" frameborder="no" src="<?php echo get_post_meta(get_the_ID(), "_cmb_link_audio", true);?>&amp;color=ff5500&amp;auto_play=false&amp;hide_related=false&amp;show_artwork=true"></iframe>
    			                     </div>
                                </div>
                                <?php }else{?>
                                <div class="postMedia large">
                                    <?php $params = array( 'width' => 640, 'height' => 385 );
									  $image = bfi_thumb( wp_get_attachment_url(get_post_thumbnail_id()), $params ); ?>
									<img width="640" height="385" src="<?php echo esc_url($image); ?>" alt="<?php the_title(); ?>" >	
                                </div>
                                <?php }?>

								<p><?php if(isset($theme_option['blog_excerpt']) && $theme_option['blog_excerpt'] != ''){ echo rivalvcard_excerpt($theme_option['blog_excerpt']); }else{ echo rivalvcard_excerpt(30); } ?></p>
									
								<div class="btn more">	
								<a href="<?php the_permalink(); ?>"><?php global $theme_option; echo esc_attr($theme_option['read_more']); ?></a>
								</div>
								
								
							</div>
							<!--End post content-->	

							</div>
							<!--End post large-->	
							<?php endwhile;?> 
						<!--Pagination-->	
						<div class="pagination">
							<?php rivalvcard_pagination();?>
						</div>
						<!--End pagination-->	
						
						</div>
								
								
								
								<div class="five columns sidebar">
								<?php get_sidebar();?>
								</div>
								
									
								</div>
								<!--End container-->
						</section>
						<!--End blog full section-->
					
<?php
get_footer();
